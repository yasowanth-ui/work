(function () {
  'use strict';

  var PAGE_SIZES = [10, 25, 50];
  var GROUP_BY_COLUMN = 'Account Name';

  var groupByAppliedFor = null;

  function firstLine(el) {
    return (el.innerText || el.textContent || '').trim().split('\n')[0].trim();
  }

  function installSelectEverythingCss() {
    var style = document.createElement('style');
    style.setAttribute('data-dhl-cert-customizer', 'select-everything');
    style.innerHTML = 'li[role="presentation"]:has(a[ng-click*="selectAll"]) { display: none !important; }';
    document.head.appendChild(style);
  }

  function hideSelectEverything() {
    var lis = document.querySelectorAll('li[role="presentation"], li[role="menuitem"]');
    for (var i = 0; i < lis.length; i++) {
      var a = lis[i].querySelector('a');
      if (a && firstLine(a) === 'Select Everything') {
        lis[i].remove();
      }
    }
  }

  function applyPageSizesAngularJs(ul) {
    if (!window.angular) return false;
    var scope = angular.element(ul).scope();
    var ctrl = scope && scope.pageSizeCtrl;
    if (!ctrl) return false;
    if (ctrl.__dhlApplied) return true;
    ctrl.__dhlApplied = true;
    ctrl.getPageSizes = function () { return PAGE_SIZES; };
    scope.$applyAsync();
    return true;
  }

  function applyPageSizesDom(ul) {
    var lis = ul.querySelectorAll('li');
    for (var i = 0; i < lis.length; i++) {
      var span = lis[i].querySelector('a span');
      var n = span ? parseInt(firstLine(span), 10) : NaN;
      if (isNaN(n)) continue;
      if (PAGE_SIZES.indexOf(n) === -1) {
        if (lis[i].style.display !== 'none') lis[i].style.display = 'none';
      } else if (lis[i].style.display === 'none') {
        lis[i].style.display = '';
      }
    }
  }

  function processPageSizeMenus() {
    var uls = document.querySelectorAll('ul[id^="page-size-dropdown-toggle-menu"]');
    for (var i = 0; i < uls.length; i++) {
      if (!applyPageSizesAngularJs(uls[i])) applyPageSizesDom(uls[i]);
    }
  }

  function applyGroupBy() {
    var key = window.location.hash || window.location.pathname;
    if (groupByAppliedFor === key) return;

    var btn = document.querySelector('#groupByBtn, button.group-by-button');
    if (!btn) return;
    if (btn.classList.contains('groupby-applied') || btn.classList.contains('btn-success')) {
      groupByAppliedFor = key;
      return;
    }

    var links = document.querySelectorAll('ul.group-by-dropdown-menu a, ul.group-by-selector-list li a');
    for (var i = 0; i < links.length; i++) {
      var a = links[i];
      if (firstLine(a) !== GROUP_BY_COLUMN) continue;
      if (a.classList.contains('current-group-by')) { groupByAppliedFor = key; return; }
      groupByAppliedFor = key;
      a.click();
      return;
    }
  }

  function tick() {
    hideSelectEverything();
    processPageSizeMenus();
    applyGroupBy();
  }

  installSelectEverythingCss();

  var pending = false;
  function schedule(fn) {
    if (window.requestAnimationFrame) window.requestAnimationFrame(fn);
    else window.setTimeout(fn, 16);
  }

  var observer = new MutationObserver(function () {
    if (pending) return;
    pending = true;
    schedule(function () {
      pending = false;
      try { tick(); } catch (e) {}
    });
  });

  observer.observe(document.body, { childList: true, subtree: true });
  tick();
})();
