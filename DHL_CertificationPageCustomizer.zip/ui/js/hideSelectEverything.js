(function () {
  // 1. CSS to hide "Select Everything"
  var style = document.createElement('style');
  style.innerHTML = 'li[role="presentation"]:has(a[ng-click*="selectAll"]) { display: none !important; }';
  document.head.appendChild(style);

  var groupByApplied = false;

  var observer = new MutationObserver(function () {
    // a) Remove "Select Everything"
    document.querySelectorAll('li[role="presentation"]').forEach(function (li) {
      var anchor = li.querySelector('a');
      if (anchor && anchor.innerText && anchor.innerText.trim() === 'Select Everything') {
        li.remove();
      }
    });

    // b) Inject 75, 100, 150, 200 into page size dropdown
    document.querySelectorAll('ul.dropdown-menu[id*="page-size-dropdown"]').forEach(function (ul) {
      if (ul.querySelector('a[aria-label="Show 75"]')) return;
      var li50 = null;
      ul.querySelectorAll('li').forEach(function (li) {
        var a = li.querySelector('a');
        if (a && a.getAttribute('aria-label') === 'Show 50') li50 = li;
      });
      if (!li50) return;
      [75, 100, 150, 200].forEach(function (size) {
        var newLi = li50.cloneNode(true);
        var newAnchor = newLi.querySelector('a');
        var newSpan = newLi.querySelector('span');
        newAnchor.setAttribute('aria-label', 'Show ' + size);
        newAnchor.removeAttribute('ng-click');
        if (newSpan) newSpan.textContent = size;
        newAnchor.addEventListener('click', function (e) {
          e.preventDefault();
          var scope = angular.element(ul).scope();
          if (scope && scope.pageSizeCtrl) {
            scope.pageSizeCtrl.changePageSize(size);
            scope.$apply();
          }
        });
        ul.appendChild(newLi);
      });
    });

    // c) Auto-apply "Group By: Account Name"
    if (!groupByApplied) {
      var groupByBtn = document.querySelector('#groupByBtn');
      if (groupByBtn) {
        if (!groupByBtn.classList.contains('btn-success')) {
          var groupByLinks = document.querySelectorAll('ul.group-by-dropdown-menu a');
          groupByLinks.forEach(function (a) {
            if (a.innerText && a.innerText.trim() === 'Account Name') {
              var scope = angular.element(a).scope();
              if (scope && scope.groupByCtrl) {
                var columns = scope.groupByCtrl.getGroupableColumns();
                columns.forEach(function (col) {
                  if (col.headerKey === 'Account Name' || col.label === 'Account Name' || col.field === 'accountName') {
                    scope.groupByCtrl.toggleGroupByColumn(col);
                    scope.$apply();
                    groupByApplied = true;
                  }
                });
                if (!groupByApplied) { a.click(); groupByApplied = true; }
              }
            }
          });
        } else {
          groupByApplied = true;
        }
      }
    }
  });

  observer.observe(document.body, { childList: true, subtree: true });
})();
