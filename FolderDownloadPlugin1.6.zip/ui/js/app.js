(function () {
	var base = PluginHelper.getPluginRestUrl('FolderDownloadPlugin/');
	var token = PluginHelper.getCsrfToken();

	function alertMsg(kind, text) {
		var el = document.getElementById('fdAlert');
		el.className = 'alert alert-' + kind;
		el.textContent = text;
		el.style.display = '';
	}

	function clearMsg() {
		document.getElementById('fdAlert').style.display = 'none';
	}

	function request(url, responseType, cb) {
		var xhr = new XMLHttpRequest();
		xhr.open('GET', url, true);
		xhr.setRequestHeader('X-XSRF-TOKEN', token);
		if (responseType) { xhr.responseType = responseType; }
		xhr.onload = function () { cb(xhr); };
		xhr.onerror = function () { cb(xhr); };
		xhr.send();
	}

	request(base + 'allowed', 'json', function (xhr) {
		if (xhr.status !== 200) {
			var el = document.getElementById('fdError');
			el.textContent = xhr.status === 404
				? 'Plugin REST endpoint not found (404). Restart the IdentityIQ node so it loads this plugin\u2019s classes.'
				: 'Could not check permissions (HTTP ' + (xhr.status || 0) + ').';
			el.style.display = '';
			return;
		}
		var ok = false;
		try {
			var d = xhr.response;
			if (typeof d === 'string') { d = JSON.parse(d); }
			ok = !!(d && d.allowed);
		} catch (e) { ok = false; }
		document.getElementById(ok ? 'fdBody' : 'fdDenied').style.display = '';
		if (ok) { wire(); }
	});

	function wire() {
		var btn = document.getElementById('fdBtn');
		var input = document.getElementById('fdPath');

		btn.onclick = function () {
			var path = (input.value || '').trim();
			if (!path) { alertMsg('warning', 'Enter a folder path.'); return; }

			clearMsg();
			btn.disabled = true;
			btn.textContent = 'Zipping…';

			var name = path.replace(/\/+$/, '').split('/').pop() || 'folder';

			request(base + 'download?path=' + encodeURIComponent(path), 'blob', function (xhr) {
				btn.disabled = false;
				btn.textContent = 'Download as zip';

				if (xhr.status !== 200) {
					if (xhr.response && typeof xhr.response.text === 'function') {
						xhr.response.text().then(function (t) {
							alertMsg('danger', t || ('Download failed (' + xhr.status + ').'));
						});
					} else {
						alertMsg('danger', 'Download failed (' + xhr.status + ').');
					}
					return;
				}

				var href = window.URL.createObjectURL(xhr.response);
				var a = document.createElement('a');
				a.href = href;
				a.download = name + '.zip';
				document.body.appendChild(a);
				a.click();
				document.body.removeChild(a);
				window.URL.revokeObjectURL(href);
				alertMsg('success', 'Downloaded ' + name + '.zip');
			});
		};

		input.onkeydown = function (e) {
			if (e.keyCode === 13) { btn.click(); }
		};
	}
})();
